# Instructions

Install packages first using the requirements.txt

Change the env file to include your own postgres username, password and dbname

Run generator.py and either input a file with the correct query structure or input through instructions in command line.

```
python generator.py
```

All the code you generated will be in \_generated.py.

```
python _generated.py
```
